# Prototype Freddy Discord Bot — Complete Feature Pack

A Python Discord bot themed around Prototype Freddy. Includes slash commands, mention replies, roleplay modes, jumpscare embeds, local soundtrack playback, voice join/leave, text-to-speech, and owner/co-owner checks.

## Commands

- `/help_prototype` — command guide
- `/prototype_freddy`, `/prototype_chat` — talk/roleplay
- `/hug`, `/friendship`, `/protect`, `/joke`, `/roast`, `/roar`, `/roleplay`
- `/jumpscare` — spooky embed (no sound by default)
- `/join`, `/leave`, `/voice` — voice connection and TTS toggle
- `/play`, `/pause`, `/resume`, `/skip`, `/queue`, `/nowplaying`, `/volume`, `/stop`
- `/status`, `/prototype_admin`, `/admin_verify`

Mentioning the bot (for example, `@Prototype Freddy`) also triggers a character reply. Message Content Intent must be enabled in the Discord Developer Portal.

## Install

1. Install Python 3.10 or newer.
2. Install FFmpeg and make sure `ffmpeg` is available on PATH.
3. Extract the ZIP.
4. Copy `.env.example` to `.env` and fill in `DISCORD_BOT_TOKEN` and a private `FREDDY_ADMIN_CODE`.
5. Install dependencies: `pip install -r requirements.txt`
6. In the Discord Developer Portal, enable **Message Content Intent**. Invite the bot with `bot` and `applications.commands` scopes and permissions to send messages, embed links, connect, and speak.
7. Run `python bot.py`.

## Voice chat notes

Join a voice channel and use `/join`. The bot can read supported typed messages aloud using Google Text-to-Speech (requires internet). `/voice state:Off` disables speech and `/leave` disconnects. It does **not** listen to or transcribe microphone speech. Discord voice-channel text chat message events can vary by client/API, so text-to-speech only works when Discord delivers those messages through the normal message event.

Music playback uses files you place in `music/`. The MP3 soundtrack uploads from the earlier conversation were not available in the current build session, so the ZIP includes the music folder and filenames/instructions, but not those audio files. Add your files to that folder and use `/play` with the exact filename. Rockstar Row is intentionally excluded. Happy (True) Ending can be added if you have an authorized copy.

## Security

Default owner IDs are `1411436991005851832` and `1552785126033858650`. Set or change them in `.env`. Do not post your bot token or admin code in chat. The admin code is checked only for the owner/co-owner accounts.

## Limitations

- The `/jumpscare` command sends a scary embed; it does not automatically play a loud sound.
- `/volume` currently explains the limitation instead of changing playback volume.
- This package was syntax-checked during packaging, but it has not been tested in a live Discord server. Discord permissions, FFmpeg, and TTS/network access affect runtime behavior.
