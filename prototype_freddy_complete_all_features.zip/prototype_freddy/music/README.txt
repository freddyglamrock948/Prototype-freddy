Put your legally obtained soundtrack files in this folder. Supported extensions: MP3, WAV, OGG, M4A.

Prototype Freddy supports local soundtrack playback with /play track:<exact filename>.
Previously used FNAF Security Breach: Ruin filenames:
01. I Got Your Message.mp3
02. Your Special Day.mp3
03. Mimic Chase.mp3
04. Scooper.mp3
05. Credits.mp3
06. I Remember (B - Side).mp3
07. Are You There (B - Side).mp3

Happy (True) Ending can be added if you have an authorized copy. Rockstar Row is intentionally not included.
The audio files from earlier chat uploads are not available in this build session, so they are not embedded in this ZIP.
