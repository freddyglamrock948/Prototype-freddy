import os, random, asyncio, tempfile
from pathlib import Path
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
from gtts import gTTS

load_dotenv()
TOKEN = os.getenv('DISCORD_BOT_TOKEN', '').strip()
OWNER_IDS = {int(x.strip()) for x in os.getenv('DISCORD_OWNER_IDS', '1411436991005851832,1552785126033858650').split(',') if x.strip().isdigit()}
CO_OWNER_IDS = {int(x.strip()) for x in os.getenv('DISCORD_CO_OWNER_IDS', '').split(',') if x.strip().isdigit()}
ADMIN_CODE = os.getenv('FREDDY_ADMIN_CODE', '').strip()
BASE = Path(__file__).parent
MUSIC_DIR = BASE / 'music'
TTS_DIR = BASE / 'tts_cache'
TTS_DIR.mkdir(exist_ok=True)

intents = discord.Intents.default()
intents.message_content = True
intents.voice_states = True
bot = commands.Bot(command_prefix='!', intents=intents, help_command=None)
queues = {}  # guild id -> list[Path]
voice_enabled = {}  # guild id -> bool

ROASTS = [
    "You have the survival instincts of a wet napkin.",
    "Even the Mimic would say your plan needs work.",
    "That idea was so bad, the Pizzaplex lights flickered in disappointment.",
    "I've seen busted endoskeletons make better decisions."
]
JOKES = [
    "Why did the animatronic bring a map? It kept taking the wrong endo-turn.",
    "I tried to tell a joke in the Pizzaplex. The punchline got lost in the vents.",
    "What's my favorite exercise? Bear-presses."
]
SCARY = [
    "**PROTOTYPE FREDDY DETECTED YOU.**\nThe lights are out. Don't turn around. 👁️",
    "**SIGNAL CORRUPTED** — footsteps detected nearby. Keep moving. ⚠️",
    "You hear metal scraping behind you. Prototype Freddy is closer than you think."
]
PROTECT = [
    "Stay behind me. I'll keep the path clear. You're not facing this alone.",
    "Protective mode engaged. Stick close, superstar. I'll watch the exits.",
    "I've got your back. If anything moves in the dark, I'll handle it."
]

def is_owner(user_id: int) -> bool:
    return user_id in OWNER_IDS or user_id in CO_OWNER_IDS

async def say_tts(guild: discord.Guild, text: str):
    vc = guild.voice_client
    if not vc or not vc.is_connected() or vc.is_playing() or vc.is_paused():
        return
    if not voice_enabled.get(guild.id, True):
        return
    try:
        path = TTS_DIR / f'{guild.id}.mp3'
        await asyncio.to_thread(lambda: gTTS(text=text[:450], lang='en').save(str(path)))
        vc.play(discord.FFmpegPCMAudio(str(path)))
    except Exception as e:
        print(f'TTS error: {e}')

async def play_next(guild: discord.Guild):
    vc = guild.voice_client
    if not vc or not vc.is_connected() or vc.is_playing() or vc.is_paused():
        return
    q = queues.get(guild.id, [])
    if not q:
        return
    track = q.pop(0)
    source = discord.FFmpegPCMAudio(str(track))
    vc.play(source, after=lambda err: asyncio.run_coroutine_threadsafe(play_next(guild), bot.loop))

@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        print(f'Synced {len(synced)} slash commands.')
    except Exception as e:
        print(f'Command sync failed: {e}')
    print(f'Prototype Freddy online as {bot.user} ({bot.user.id})')

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return
    if bot.user and bot.user in message.mentions:
        text = message.content.lower()
        if any(x in text for x in ['help', 'commands']):
            reply = 'Try `/help_prototype` to see my commands. Keep your flashlight ready.'
        elif any(x in text for x in ['scare', 'mimic', 'behind']):
            reply = random.choice(SCARY)
        elif any(x in text for x in ['protect', 'safe', 'help me']):
            reply = random.choice(PROTECT)
        else:
            reply = random.choice([
                'Hey, superstar. Prototype Freddy is online. What do you need?',
                'I heard you. Stay alert — this place has a few surprises.',
                'System check complete. I am watching the halls. What is up?'
            ])
        await message.reply(reply, mention_author=False)
    # Speak typed messages in the voice channel's associated text chat when supported by Discord.
    vc = message.guild.voice_client
    if vc and vc.is_connected() and vc.channel and message.channel.id == vc.channel.id:
        if len(message.content.strip()) > 0 and not message.content.startswith('/'):
            await say_tts(message.guild, f'{message.author.display_name} says: {message.content}')

@bot.tree.command(name='help_prototype', description='Show all Prototype Freddy commands')
async def help_prototype(interaction: discord.Interaction):
    embed = discord.Embed(title='Prototype Freddy — Command Guide', color=discord.Color.dark_red())
    embed.description = (
        '**Character:** `/prototype_freddy`, `/prototype_chat`, `/hug`, `/friendship`, `/protect`, `/joke`, `/roast`, `/roar`, `/roleplay`, `/jumpscare`\n'
        '**Music:** `/play`, `/pause`, `/resume`, `/skip`, `/queue`, `/nowplaying`, `/volume`, `/stop`\n'
        '**Voice:** `/join`, `/leave`, `/voice` — reads supported text-chat messages aloud; does not transcribe microphone speech.\n'
        '**Utility/security:** `/status`, `/prototype_admin`, `/admin_verify`'
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name='prototype_freddy', description='Talk to Prototype Freddy')
@app_commands.describe(message='What would you like to say?')
async def prototype_freddy(interaction: discord.Interaction, message: str = 'Hello, Prototype Freddy!'):
    await interaction.response.send_message(f'🐻‍❄️ **Prototype Freddy:** {random.choice(["System online. What is your objective?", "Stay close, superstar.", "I can help — but keep your eyes open.", "I remember this place... more than I want to."])}\n*You said:* {message[:300]}')

@bot.tree.command(name='prototype_chat', description='Get a roleplay reply from Prototype Freddy')
@app_commands.describe(message='Your message')
async def prototype_chat(interaction: discord.Interaction, message: str):
    await interaction.response.send_message(f'**Prototype Freddy:** {random.choice(["I am listening.", "That sounds important. Tell me more.", "Scanning the area... go on.", "I will stay with you while we figure this out."])}\n*{message[:300]}*')

@bot.tree.command(name='hug', description='Give Prototype Freddy a friendly hug')
async def hug(interaction: discord.Interaction):
    await interaction.response.send_message('🫂 *Prototype Freddy gives you a careful, slightly creaky hug.* “You are safe for now.”')

@bot.tree.command(name='friendship', description='Boost your friendship with Prototype Freddy')
async def friendship(interaction: discord.Interaction):
    await interaction.response.send_message(random.choice(['⭐ Friendship level increased! “You are part of the team now.”', '💙 “I trust you. Let us stick together.”', '🤝 “Teamwork makes survival more likely.”']))

@bot.tree.command(name='protect', description='Activate Prototype Freddy protective mode')
async def protect(interaction: discord.Interaction):
    await interaction.response.send_message('🛡️ ' + random.choice(PROTECT))

@bot.tree.command(name='joke', description='Hear a Prototype Freddy joke')
async def joke(interaction: discord.Interaction):
    await interaction.response.send_message('🎤 ' + random.choice(JOKES))

@bot.tree.command(name='roast', description='Get a playful Prototype Freddy roast')
@app_commands.describe(target='Optional person to roast')
async def roast(interaction: discord.Interaction, target: discord.Member | None = None):
    who = target.mention + ', ' if target else ''
    await interaction.response.send_message(f'🔥 {who}{random.choice(ROASTS)}')

@bot.tree.command(name='roar', description='Prototype Freddy unleashes a roar')
async def roar(interaction: discord.Interaction):
    await interaction.response.send_message('**GRRRRRRRAAAAAAAAHHHH!!** 🔊\n*The metal walls vibrate as Prototype Freddy roars.*')
    await say_tts(interaction.guild, 'Grrrrraaaaah!')

@bot.tree.command(name='roleplay', description='Choose a Prototype Freddy roleplay mode')
@app_commands.choices(mode=[app_commands.Choice(name='Scary', value='scary'), app_commands.Choice(name='Protective', value='protective'), app_commands.Choice(name='Damaged voice', value='damaged'), app_commands.Choice(name='Damage mode', value='damage')])
async def roleplay(interaction: discord.Interaction, mode: app_commands.Choice[str]):
    replies = {
        'scary': '👁️ **SCANNER ACTIVE.** I can hear every step. Do not wander off.',
        'protective': random.choice(PROTECT),
        'damaged': 'S-s-systems... unstable. I am still here. Stay behind me... *static crackles*',
        'damage': '⚠️ **DAMAGE MODE ACTIVE** — *servo grinding, voice glitching* “I... WILL... PROTECT... YOU.”'
    }
    await interaction.response.send_message(replies[mode.value])

@bot.tree.command(name='jumpscare', description='Trigger a spooky Prototype Freddy jumpscare')
async def jumpscare(interaction: discord.Interaction):
    embed = discord.Embed(title='⚠️ PROTOTYPE FREDDY — JUMPSCARE', description=random.choice(SCARY), color=discord.Color.red())
    embed.set_footer(text='Turn your volume down if you are sensitive to loud sounds. No audio is played by this command.')
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name='join', description='Join your current voice channel')
async def join(interaction: discord.Interaction):
    if not interaction.guild or not isinstance(interaction.user, discord.Member) or not interaction.user.voice or not interaction.user.voice.channel:
        return await interaction.response.send_message('Join a voice channel first, then run `/join`.', ephemeral=True)
    channel = interaction.user.voice.channel
    try:
        vc = interaction.guild.voice_client
        if vc and vc.is_connected():
            await vc.move_to(channel)
        else:
            await channel.connect()
        voice_enabled[interaction.guild.id] = True
        await interaction.response.send_message(f'🔊 Prototype Freddy joined **{channel.name}**. Use `/voice` to toggle text-to-speech.')
    except Exception as e:
        await interaction.response.send_message(f'I could not join that voice channel: `{e}`', ephemeral=True)

@bot.tree.command(name='leave', description='Leave the current voice channel')
async def leave(interaction: discord.Interaction):
    vc = interaction.guild.voice_client if interaction.guild else None
    if vc:
        queues[interaction.guild.id] = []
        await vc.disconnect(force=True)
        await interaction.response.send_message('👋 Prototype Freddy left the voice channel.')
    else:
        await interaction.response.send_message('I am not in a voice channel.', ephemeral=True)

@bot.tree.command(name='voice', description='Enable or disable spoken text-to-speech')
@app_commands.choices(state=[app_commands.Choice(name='On', value='on'), app_commands.Choice(name='Off', value='off')])
async def voice(interaction: discord.Interaction, state: app_commands.Choice[str]):
    voice_enabled[interaction.guild_id] = state.value == 'on'
    await interaction.response.send_message(f'🔊 Voice replies: **{state.value.upper()}**. I read supported text messages aloud; I do not listen to microphone speech.')

@bot.tree.command(name='play', description='Play a local soundtrack MP3 by filename')
@app_commands.describe(track='Exact filename from the music folder')
async def play(interaction: discord.Interaction, track: str):
    if not interaction.guild:
        return await interaction.response.send_message('Use this command in a server.', ephemeral=True)
    if not interaction.user.voice or not interaction.user.voice.channel:
        return await interaction.response.send_message('Join a voice channel first.', ephemeral=True)
    files = {p.name.lower(): p for p in MUSIC_DIR.iterdir() if p.is_file() and p.suffix.lower() in {'.mp3', '.wav', '.ogg', '.m4a'}}
    path = files.get(Path(track).name.lower())
    if not path:
        available = ', '.join(p.name for p in MUSIC_DIR.iterdir() if p.is_file() and p.suffix.lower() in {'.mp3', '.wav', '.ogg', '.m4a'}) or 'No tracks installed yet'
        return await interaction.response.send_message(f'Track not found. Add audio files to `music/`. Available: {available}', ephemeral=True)
    vc = interaction.guild.voice_client
    try:
        if not vc or not vc.is_connected():
            vc = await interaction.user.voice.channel.connect()
        elif vc.channel != interaction.user.voice.channel:
            await vc.move_to(interaction.user.voice.channel)
        q = queues.setdefault(interaction.guild.id, [])
        if vc.is_playing() or vc.is_paused():
            q.append(path)
            await interaction.response.send_message(f'➕ Queued **{path.name}** (position {len(q)}).')
        else:
            vc.play(discord.FFmpegPCMAudio(str(path)), after=lambda err: asyncio.run_coroutine_threadsafe(play_next(interaction.guild), bot.loop))
            await interaction.response.send_message(f'▶️ Now playing **{path.name}**.')
    except Exception as e:
        await interaction.response.send_message(f'Playback failed: `{e}`. Check FFmpeg and bot voice permissions.', ephemeral=True)

@bot.tree.command(name='pause', description='Pause the current track')
async def pause(interaction: discord.Interaction):
    vc = interaction.guild.voice_client if interaction.guild else None
    if vc and vc.is_playing():
        vc.pause(); await interaction.response.send_message('⏸️ Paused.')
    else: await interaction.response.send_message('Nothing is playing.', ephemeral=True)

@bot.tree.command(name='resume', description='Resume the current track')
async def resume(interaction: discord.Interaction):
    vc = interaction.guild.voice_client if interaction.guild else None
    if vc and vc.is_paused():
        vc.resume(); await interaction.response.send_message('▶️ Resumed.')
    else: await interaction.response.send_message('Nothing is paused.', ephemeral=True)

@bot.tree.command(name='skip', description='Skip the current track')
async def skip(interaction: discord.Interaction):
    vc = interaction.guild.voice_client if interaction.guild else None
    if vc and (vc.is_playing() or vc.is_paused()):
        vc.stop(); await interaction.response.send_message('⏭️ Skipped.')
    else: await interaction.response.send_message('Nothing is playing.', ephemeral=True)

@bot.tree.command(name='queue', description='Show queued tracks')
async def queue(interaction: discord.Interaction):
    q = queues.get(interaction.guild_id, [])
    await interaction.response.send_message('🎶 **Queue**\n' + ('\n'.join(f'{i+1}. {p.name}' for i,p in enumerate(q)) if q else 'The queue is empty.'))

@bot.tree.command(name='nowplaying', description='Show the current playback status')
async def nowplaying(interaction: discord.Interaction):
    vc = interaction.guild.voice_client if interaction.guild else None
    await interaction.response.send_message('🎵 Audio is playing.' if vc and vc.is_playing() else ('⏸️ Audio is paused.' if vc and vc.is_paused() else 'Nothing is playing.'))

@bot.tree.command(name='volume', description='Set music volume from 10 to 100 percent')
@app_commands.describe(percent='Volume percentage (10–100)')
async def volume(interaction: discord.Interaction, percent: app_commands.Range[int, 10, 100]):
    vc = interaction.guild.voice_client if interaction.guild else None
    if not vc or not (vc.is_playing() or vc.is_paused()):
        return await interaction.response.send_message('Start a track first.', ephemeral=True)
    # FFmpegPCMAudio is not wrapped in PCMVolumeTransformer in this simple player.
    await interaction.response.send_message('Volume control needs a track restart in this build; use your Discord client volume for now.', ephemeral=True)

@bot.tree.command(name='stop', description='Stop music and clear the queue')
async def stop(interaction: discord.Interaction):
    if interaction.guild:
        queues[interaction.guild.id] = []
        vc = interaction.guild.voice_client
        if vc and (vc.is_playing() or vc.is_paused()): vc.stop()
    await interaction.response.send_message('⏹️ Playback stopped and queue cleared.')

@bot.tree.command(name='status', description='Check Prototype Freddy system status')
async def status(interaction: discord.Interaction):
    vc = interaction.guild.voice_client if interaction.guild else None
    embed = discord.Embed(title='Prototype Freddy — System Status', color=discord.Color.dark_red())
    embed.add_field(name='Bot', value='Online', inline=True)
    embed.add_field(name='Voice', value='Connected' if vc and vc.is_connected() else 'Disconnected', inline=True)
    embed.add_field(name='TTS', value='Enabled' if voice_enabled.get(interaction.guild_id, True) else 'Disabled', inline=True)
    embed.add_field(name='Latency', value=f'{round(bot.latency*1000)} ms', inline=True)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name='prototype_admin', description='Show security status (owner/co-owner only)')
async def prototype_admin(interaction: discord.Interaction):
    if not is_owner(interaction.user.id):
        return await interaction.response.send_message('⛔ Owner/co-owner access only.', ephemeral=True)
    await interaction.response.send_message(f'🔐 Access verified. Owner/co-owner security is active for your account. Admin code configured: **{"Yes" if ADMIN_CODE else "No — set FREDDY_ADMIN_CODE in .env"}**', ephemeral=True)

@bot.tree.command(name='admin_verify', description='Verify with the private admin code')
@app_commands.describe(code='Private code from your .env file')
async def admin_verify(interaction: discord.Interaction, code: str):
    if not is_owner(interaction.user.id):
        return await interaction.response.send_message('⛔ Owner/co-owner access only.', ephemeral=True)
    if not ADMIN_CODE:
        return await interaction.response.send_message('Admin code is not configured. Set FREDDY_ADMIN_CODE in `.env`.', ephemeral=True)
    if not __import__('hmac').compare_digest(code, ADMIN_CODE):
        return await interaction.response.send_message('❌ Incorrect code.', ephemeral=True)
    await interaction.response.send_message('✅ Admin verification successful.', ephemeral=True)

if __name__ == '__main__':
    if not TOKEN:
        raise SystemExit('Missing DISCORD_BOT_TOKEN. Copy .env.example to .env and add your bot token.')
    bot.run(TOKEN)
